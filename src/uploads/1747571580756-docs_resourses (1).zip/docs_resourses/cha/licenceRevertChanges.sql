 select reject_invoice,net_weight,* from chail.job_invoice_details where job_code='AOP/00877/23-24';
select sub_status,* from chail.job_details   where job_code='AOP/00878/23-24' --Invoice Edit In Progress;

select assign_license,status,* FROM chail.license_utilization   WHERE   job_code = 'AOP/00877/23-24' ;
select license_type,assign_license,reject_invoice,is_deleted,* FROM chail.job_po_services   WHERE   job_code = 'AOP/00877/23-24' ;

select js.license_type,
lu.item_serial_no,lu.lrn,js.job_code,lu.po_id,lu.assessable_value,lu.duty_amount ,
(	SELECT  remaining_cif FROM chail.license_header_master WHERE lrn = lu.lrn ) as master_remaining_cif,
(	SELECT  remaining_dcv FROM chail.license_header_master WHERE lrn = lu.lrn ) as master_remaining_dcv,
(	SELECT  remaining_quantity FROM chail.license_master WHERE lrn = lu.lrn and item_serial_no = lu.item_serial_no limit 1) as master_remaining_quantity
FROM chail.license_utilization lu
LEFT JOIN chail.job_po_services js ON js.id = lu.po_id
WHERE  
js.job_code = 'AOP/00877/23-24' 
and lu.status = 'Active' 
and js.assign_license = true 
and lu.assign_license = true 


-- update chail.license_utilization set status = 'Active' , assign_license = true WHERE   job_code = 'AOP/00877/23-24' ;
-- update chail.job_po_services set  assign_license = true,reject_invoice = false  WHERE   job_code = 'AOP/00877/23-24' ;
-- update chail.job_invoice_details set   reject_invoice = false WHERE   job_code = 'AOP/00877/23-24' ;
-- update chail.job_details set   sub_status = 'Invoice Edit In Progress' WHERE   job_code = 'AOP/00877/23-24' ;
  