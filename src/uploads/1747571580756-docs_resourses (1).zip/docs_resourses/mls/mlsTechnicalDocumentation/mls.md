# mls

-- DELETE FROM master_data_management.port_service_master
update master_data_management.port_service_master set is_active = 'false'--, update_remarks = 'dublicate record'
Where port_service_master_id IN (
SELECT a.port_service_master_id FROM (SELECT port_service_master_id,service_name, voyage_type, port_name, 
      ROW_NUMBER() OVER (PARTITION BY service_name, voyage_type, port_name ORDER BY service_name) AS row_num
FROM master_data_management.port_service_master psm
WHERE 
--psm.port_name = 'Haldia' AND
psm.is_active = true
)a Where a.row_num>1 )
ALTER TABLE IF EXISTS mls.fda_submission ADD COLUMN IF NOT EXISTS extra_port_stay numeric DEFAULT 0;

# mlsBugs

Other services tariff_params not getting hence tally has param value 1 is not comming after fetch 



# mlsAllbugs


Docs
To generate SO or invoice or DN any sap transaction 
1st need to dave so group and radio button for that line item then re open the job then can proceed for so,invoice or dn or any sap transaction 

<!-- 
#2 even after invoice user can add owner or husbandry is enable add customer with owner or husbandry options ?
no non operational bh details pfda
#4RECHECK in defaultValue if user updates it to another value that wont be retained "TM/MLS/PDA/FY23/00170
#5 P3 Auto fetched activity bug 
haldia create pda FIFO ,import
: Addding mooring ,activity came automatically ,gave contribution,all other but formula didnt came
- means call formula api when autopopulating activity type because user wont reselect activity type again
#6 tally TM/MLS/PDA/FY25/01543 FIFO Haldia Import -->
<!--

TEST:
Dhamra FICO coastal import Consolidate and tally recal and fetch cals
fifo exporthaldia add mooring

devNotes:
in code if  we do is null or true then issue because false in update goes as null-->
<!-- #0  UPDATE mls.fda_submission SET so_generated = true (Ref update fda sumbission) add this part of code to update sap order details checkbox...xx new function also -->

<!-- #1 TM/MLS/PDA/FY25/01547 pda quotationid do simple fetch part c params tally_consolidate_bug branch  -->

mls
Deployed and merges our latest QA code in below branch
Branch :msr_qa_6_sep_2024 in tmill devops repo 


For Added service GRT Specific formula should come and calculations should not come
ecchange rate taking from header for addedServices
Added services Only Berth hire rebate wrong taking autopop rebate of berth hire
Added BH service taking minimum charges
#1 gave 99% to BH fetched service and saved then fetch header 100% , incorrect port rates
#2 tab out on contribution then param value not changing



# mlsUpdateMail

1042 bh auto pop formula nd param
1041 isphl user enter


Req Approval  :  Tally Param check Part C params Not Displaying and updating 
Req Approval  :  Adding a new service in Part A activity type auto populated but formula didn’t came 
Req Approval  :  Need to use respective  table for customer cargo details in pfda and fda
Req Approval  :  3 decimals CR in Param value

Adjustments
Rebates
SO generated LIs should not affect
Dublicates
Totals
Params Calculating
Params Retaining 
