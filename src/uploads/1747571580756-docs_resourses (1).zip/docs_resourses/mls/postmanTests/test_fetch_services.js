const baseUrl =
  "https://qamdm.azurewebsites.net/masterDataOperationsapi/master/listVessels";
const authToken =
  "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2VtYWlsIjoibXNyQHRtaWxsdGQuY29tIiwic2VjcmV0IjoiVE1JTExfTE9CIiwiZXhwaXJ5IjoiMjAyMy0wNi0wM1QxMDoyMTo1MS4yNTBaIn0.5C5EIIJvEv7PPLJmSZ1Lntno7WP9tro3psVP0Tdy0cI";

//setting grt
pm.sendRequest(
  {
    url: baseUrl,
    method: "GET",
    header: { token: authToken },
  },
  function (err, response) {
    if (err) {
      console.error(err);
      return;
    }

    pm.test("Fetching vessel_grt", function () {
      let vessel_grt = 0;
      for (let i = 0; i < response.json().Records.length; i++) {
        if (response.json().Records[i].vessel_master_id == 4) {
          vessel_grt = response.json().Records[i].vessel_grt;
          pm.globals.set("vessel_grt", vessel_grt);
        }
      }
      pm.expect(response.code).to.equal(200);
    });
  }
);

//Service respective checks
pm.test("Validating inr_port_rate calculation", function () {
  let grt = pm.globals.get("vessel_grt");
  var port_services = pm.response.json().Records["port_services"];
  const req_body = JSON.parse(pm.request.body);

    // console.log("Check details",
    // "vessel_id", req_body.vessel_id,
    // "vessel_grt ::", grt,
    // )

  for (let i = 0; i < port_services.length; i++) {
    // if(service_name  != 'Consolidated vessel related charges') continue

    const service_name = port_services[i].service_name;
    let usd_port_rate = 0;
    if (service_name == "Consolidated vessel related charges") {
      // console.log("tariff ::", port_services[i].tariff);
      let mtCargo = Number(req_body.customer_cargo_list[0].cargo_quantity); // 10000;
      usd_port_rate = mtCargo * 60;
      console.log(
        `calculated ${service_name}`,
        usd_port_rate.toFixed(2),
       'got in  res ', port_services[i].inr_port_rate
      );
      pm.expect(usd_port_rate.toFixed(2)).to.eql(
        port_services[i].inr_port_rate
      );
    }
    if (service_name == "Berth Hire") {
      let tariff = port_services[i].tariff;
      let hourCount = Number(port_services[i].berth_hire_hour_count); //port_services[i].tariff_params[1].tariff_param; console.log("hourCount ::",hourCount)
      //   console.log("tariff ::", tariff,hourCount );
      usd_port_rate = grt * hourCount * tariff;
      console.log(
        `Calculated ${service_name}`,
        usd_port_rate.toFixed(2),
       `got in res`, port_services[i].usd_port_rate////0.0104*36272*12==4526.7456
      );
      pm.expect(usd_port_rate.toFixed(2)).to.eql(
        port_services[i].usd_port_rate
      );
    }
    if (service_name == "Anchorage Charge") {
      let tariff = port_services[i].tariff;
      let hourCount = Number(port_services[i].anchorage_hrs_count); //port_services[i].tariff_params[1].tariff_param; console.log("hourCount ::",hourCount)
      //   console.log("tariff ::", tariff,hourCount );
      usd_port_rate = grt * hourCount * tariff;
      console.log(
        `Calculated ${service_name}`,
        usd_port_rate.toFixed(2),
       `got in res`, port_services[i].usd_port_rate////0.0104*36272*12==4526.7456
      );
      pm.expect(usd_port_rate.toFixed(2)).to.eql(
        port_services[i].usd_port_rate
      );
    }

    // console.log(
    //   `test ${service_name}`,
    //   usd_port_rate.toFixed(2),
    //   port_services[i].usd_port_rate
    // );
  }
  pm.globals.unset("vessel_grt");
  pm.response.to.have.status(200);
});

pm.test("Validating Cargo quantity split", function () {
  const req_body = JSON.parse(pm.request.body);
  let tot_customer_quantity = 0;
  for (var i = 0; i < req_body.customer_cargo_list.length; i++) {
    tot_customer_quantity += Number(
      req_body.customer_cargo_list[i].cargo_quantity
    );
  }
  //   console.log("check cargo qty",req_body.cargo_quantity,tot_customer_quantity)
  pm.expect(req_body.cargo_quantity).to.eql(tot_customer_quantity);
  pm.response.to.have.status(200);
});
