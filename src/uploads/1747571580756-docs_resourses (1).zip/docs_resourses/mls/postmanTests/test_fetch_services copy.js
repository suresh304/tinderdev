
// let  vessel_grt = 0
// for(let i = 0; i< response.json().Records.length ; i++){
//     if(response.json().Records[i].vessel_master_id == 15) {
//         vessel_grt = response.json().Records[i].vessel_grt 
//     pm.variables.set("vessel_grt",vessel_grt);
// }
// }
const baseUrl = 'https://qamdm.azurewebsites.net/masterDataOperationsapi/master/listVessels';
const authToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2VtYWlsIjoibXNyQHRtaWxsdGQuY29tIiwic2VjcmV0IjoiVE1JTExfTE9CIiwiZXhwaXJ5IjoiMjAyMy0wNi0wM1QxMDoyMTo1MS4yNTBaIn0.5C5EIIJvEv7PPLJmSZ1Lntno7WP9tro3psVP0Tdy0cI';
// const tariffs = {
//     berthHire = 
// }


pm.sendRequest({
url:baseUrl,
method: 'GET',
header: {'token':  authToken}
}, function (err, response) {
if (err) {
console.error(err);
return;
}

pm.test('Fetching vessel_grt', function () {
//   console.log("vessel_master_id",response.json().Records[0].vessel_master_id)
let  vessel_grt = 0
for(let i = 0; i< response.json().Records.length ; i++){
if(response.json().Records[i].vessel_master_id == 4) {
    vessel_grt = response.json().Records[i].vessel_grt 
pm.globals.set('vessel_grt',vessel_grt);
}
}
pm.expect(response.code).to.equal(200);
});
});

pm.test('Validating usd_port_rate calculation', function () {
let grt =  pm.globals.get('vessel_grt'); console.log("vessel_grt ::",grt)
var port_services = pm.response.json().Records['port_services']
const req_body = JSON.parse(pm.request.body)
console.log("reqqinp",req_body.vessel_id)
for(let i = 0; i< port_services.length ; i++){
  console.log("service:::",port_services[i].service_name)
  //Service respective checks
let inr_port_rate = 0
if(port_services[i].service_name  == 'Consolidated vessel related charges') {
let tariff = port_services[i].tariff; console.log("tariff ::",tariff)
let  mtCargo = 10000
inr_port_rate = mtCargo*60 
}
if(port_services[i].service_name  == 'Berth Hire'){
  let tariff = port_services[i].tariff; console.log("tariff ::",tariff)
  let hourCount = 2.06//port_services[i].tariff_params[1].tariff_param; console.log("hourCount ::",hourCount)
  inr_port_rate =  grt*hourCount*tariff; 
}

console.log(`test ${port_services[i].service_name }`,(inr_port_rate).toFixed(2), port_services[i].inr_port_rate)
    // if(port_services[i].service_name  != 'Consolidated vessel related charges') continue
}
pm.globals.unset('vessel_grt')
pm.response.to.have.status(200);
});
